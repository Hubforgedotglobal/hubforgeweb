import { Menu, X, ChevronDown, Mail, ExternalLink } from 'lucide-react';
import { useState, useEffect } from 'react';

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-black/95 backdrop-blur-lg' : 'bg-transparent'}`}>
        <div className="max-w-[1920px] mx-auto px-6 lg:px-12 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img src="/HFD_Logo.png" alt="HubForge" className="h-10 w-auto brightness-0 invert" />
            </div>

            <div className="hidden lg:flex items-center space-x-8 text-sm font-medium uppercase tracking-wider">
              <button onClick={() => scrollToSection('mission')} className="hover:text-gray-300 transition-colors">Mission</button>
              <button onClick={() => scrollToSection('programs')} className="hover:text-gray-300 transition-colors">Programs</button>
              <button onClick={() => scrollToSection('impact')} className="hover:text-gray-300 transition-colors">Impact</button>
              <button onClick={() => scrollToSection('contact')} className="hover:text-gray-300 transition-colors">Contact</button>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden"
            >
              {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>

          {mobileMenuOpen && (
            <div className="lg:hidden mt-6 pb-6 space-y-4 text-sm font-medium uppercase tracking-wider">
              <button onClick={() => scrollToSection('mission')} className="block w-full text-left hover:text-gray-300 transition-colors">Mission</button>
              <button onClick={() => scrollToSection('programs')} className="block w-full text-left hover:text-gray-300 transition-colors">Programs</button>
              <button onClick={() => scrollToSection('impact')} className="block w-full text-left hover:text-gray-300 transition-colors">Impact</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left hover:text-gray-300 transition-colors">Contact</button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section - Full Screen */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-neutral-900 to-black opacity-90"></div>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDMpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20"></div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 text-center">
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tight mb-8 leading-none">
            BUILDING GLOBAL<br />BRIDGES
          </h1>
          <p className="text-xl md:text-2xl lg:text-3xl text-gray-300 font-light tracking-wide max-w-4xl mx-auto mb-12">
            Rooted in local action. Powered by evidence.
          </p>
          <button
            onClick={() => scrollToSection('mission')}
            className="inline-flex items-center space-x-2 text-sm uppercase tracking-widest font-medium border-2 border-white px-10 py-4 hover:bg-white hover:text-black transition-all duration-300"
          >
            <span>Explore</span>
            <ChevronDown size={20} />
          </button>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown size={32} className="text-gray-400" />
        </div>
      </section>

      {/* Mission Section - Full Screen */}
      <section id="mission" className="relative min-h-screen flex items-center py-20 lg:py-32">
        <div className="max-w-[1920px] mx-auto px-6 lg:px-12 w-full">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <div>
              <div className="text-sm uppercase tracking-widest text-gray-400 mb-6">Our Mission</div>
              <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-8">
                Empowering Communities to Drive Change
              </h2>
              <p className="text-xl md:text-2xl text-gray-300 leading-relaxed font-light">
                We envision a world where communities, youth, and grassroots changemakers have the strength to build and share evidence, uniting local wisdom with global knowledge.
              </p>
            </div>
            <div className="space-y-8">
              <div className="border-l-4 border-white pl-6">
                <h3 className="text-2xl font-bold mb-3">Evidence with Heart</h3>
                <p className="text-gray-400">Data should serve people, not the other way around.</p>
              </div>
              <div className="border-l-4 border-white pl-6">
                <h3 className="text-2xl font-bold mb-3">Local Wisdom First</h3>
                <p className="text-gray-400">Communities know their context best—we listen and co-create.</p>
              </div>
              <div className="border-l-4 border-white pl-6">
                <h3 className="text-2xl font-bold mb-3">Global Connections</h3>
                <p className="text-gray-400">Knowledge is collective power; we share it freely.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-20 lg:py-32 bg-white text-black">
        <div className="max-w-[1920px] mx-auto px-6 lg:px-12">
          <div className="grid md:grid-cols-3 gap-12 lg:gap-16">
            <div className="text-center">
              <div className="text-6xl lg:text-7xl font-bold mb-4">Global</div>
              <div className="text-xl text-gray-600 uppercase tracking-wider">Network</div>
            </div>
            <div className="text-center">
              <div className="text-6xl lg:text-7xl font-bold mb-4">Local</div>
              <div className="text-xl text-gray-600 uppercase tracking-wider">Impact</div>
            </div>
            <div className="text-center">
              <div className="text-6xl lg:text-7xl font-bold mb-4">Evidence</div>
              <div className="text-xl text-gray-600 uppercase tracking-wider">Driven</div>
            </div>
          </div>
        </div>
      </section>

      {/* Programs Section */}
      <section id="programs" className="relative min-h-screen py-20 lg:py-32">
        <div className="max-w-[1920px] mx-auto px-6 lg:px-12">
          <div className="text-center mb-20">
            <div className="text-sm uppercase tracking-widest text-gray-400 mb-6">What We Do</div>
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold">Our Programs</h2>
          </div>

          <div className="space-y-4">
            {/* Program 1 */}
            <div className="group relative overflow-hidden border border-white/20 hover:border-white transition-all duration-500">
              <div className="p-10 lg:p-16">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
                  <div className="lg:max-w-2xl">
                    <h3 className="text-4xl lg:text-5xl font-bold mb-4">Impact Lab</h3>
                    <p className="text-xl text-gray-400">
                      A worldwide ecosystem of volunteers, offering essential skills and tools to grassroots groups—transforming local action with global support.
                    </p>
                  </div>
                  <div className="text-8xl lg:text-9xl font-bold text-white/5 group-hover:text-white/10 transition-all duration-500">01</div>
                </div>
              </div>
            </div>

            {/* Program 2 */}
            <div className="group relative overflow-hidden border border-white/20 hover:border-white transition-all duration-500">
              <div className="p-10 lg:p-16">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
                  <div className="lg:max-w-2xl">
                    <h3 className="text-4xl lg:text-5xl font-bold mb-4">EvalAtlas</h3>
                    <p className="text-xl text-gray-400">
                      Connecting local evaluation talent to global opportunities. An open-access directory forging international collaboration.
                    </p>
                  </div>
                  <div className="text-8xl lg:text-9xl font-bold text-white/5 group-hover:text-white/10 transition-all duration-500">02</div>
                </div>
              </div>
            </div>

            {/* Program 3 */}
            <div className="group relative overflow-hidden border border-white/20 hover:border-white transition-all duration-500">
              <div className="p-10 lg:p-16">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
                  <div className="lg:max-w-2xl">
                    <h3 className="text-4xl lg:text-5xl font-bold mb-4">Glocal Impact Awards</h3>
                    <p className="text-xl text-gray-400">
                      Celebrating changemakers who embody local leadership and global impact. Amplifying evidence-driven success worldwide.
                    </p>
                  </div>
                  <div className="text-8xl lg:text-9xl font-bold text-white/5 group-hover:text-white/10 transition-all duration-500">03</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section id="impact" className="relative min-h-screen flex items-center py-20 lg:py-32 bg-gradient-to-b from-black to-neutral-900">
        <div className="max-w-[1920px] mx-auto px-6 lg:px-12 w-full">
          <div className="max-w-5xl mx-auto text-center">
            <div className="text-sm uppercase tracking-widest text-gray-400 mb-6">Why HubForge Exists</div>
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-12">
              Because Impact Shouldn't Depend on Privilege
            </h2>
            <p className="text-2xl md:text-3xl text-gray-300 leading-relaxed font-light mb-16">
              Every changemaker—no matter where they are—should have access to evidence, tools, networks, and opportunities to make their solutions stronger and their voices louder.
            </p>
            <div className="grid md:grid-cols-2 gap-8 text-left">
              <div className="border border-white/20 p-8 lg:p-10">
                <h3 className="text-3xl font-bold mb-4">Our Vision</h3>
                <p className="text-gray-400 text-lg">
                  A just and thriving world where communities have the ecosystem strength to build and share evidence, uniting local wisdom and global knowledge.
                </p>
              </div>
              <div className="border border-white/20 p-8 lg:p-10">
                <h3 className="text-3xl font-bold mb-4">Our Approach</h3>
                <p className="text-gray-400 text-lg">
                  Nurturing a globally connected, locally rooted ecosystem where changemakers can collaborate, learn, and thrive—from village leaders to global institutions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="relative min-h-screen flex items-center py-20 lg:py-32">
        <div className="max-w-[1920px] mx-auto px-6 lg:px-12 w-full">
          <div className="max-w-4xl mx-auto text-center">
            <div className="text-sm uppercase tracking-widest text-gray-400 mb-6">Get In Touch</div>
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-12">
              Let's Connect
            </h2>
            <p className="text-2xl text-gray-300 mb-16 leading-relaxed">
              Interested in working or learning with us? Connect for partnership, volunteering, or collaboration—locally or globally.
            </p>

            <div className="grid md:grid-cols-2 gap-8 mb-16">
              <a
                href="mailto:hubforgeglobal@gmail.com"
                className="group border-2 border-white p-8 lg:p-10 hover:bg-white hover:text-black transition-all duration-300"
              >
                <Mail className="mx-auto mb-4" size={40} />
                <div className="text-sm uppercase tracking-widest mb-2 text-gray-400 group-hover:text-black">Primary Contact</div>
                <div className="text-lg font-medium">hubforgeglobal@gmail.com</div>
              </a>
              <a
                href="mailto:shaishsrhor@hubforgeglobal.com"
                className="group border-2 border-white p-8 lg:p-10 hover:bg-white hover:text-black transition-all duration-300"
              >
                <Mail className="mx-auto mb-4" size={40} />
                <div className="text-sm uppercase tracking-widest mb-2 text-gray-400 group-hover:text-black">Alternative Contact</div>
                <div className="text-lg font-medium">shaishsrhor@hubforgeglobal.com</div>
              </a>
            </div>

            <p className="text-gray-400">
              We're passionate about bridging diverse perspectives and turning complex challenges into impactful, locally relevant, and globally recognized solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-12 border-t border-white/10">
        <div className="max-w-[1920px] mx-auto px-6 lg:px-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center space-x-3">
              <img src="/HFD_Logo.png" alt="HubForge" className="h-8 w-auto brightness-0 invert" />
            </div>
            <div className="flex flex-wrap justify-center gap-8 text-sm uppercase tracking-wider text-gray-400">
              <button onClick={() => scrollToSection('mission')} className="hover:text-white transition-colors">Mission</button>
              <button onClick={() => scrollToSection('programs')} className="hover:text-white transition-colors">Programs</button>
              <button onClick={() => scrollToSection('impact')} className="hover:text-white transition-colors">Impact</button>
              <button onClick={() => scrollToSection('contact')} className="hover:text-white transition-colors">Contact</button>
            </div>
            <div className="text-sm text-gray-400">
              © {new Date().getFullYear()} HubForge
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
