# HubForge Global Impact Network

A world-class website for HubForge - Building global bridges, rooted in local action.

## Features

- 🚀 SpaceX-inspired sleek design
- 📱 Fully responsive
- ⚡ Lightning fast performance
- 🎨 Modern UI with smooth animations
- 🌐 Optimized for GitHub Pages

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- Lucide Icons

## Development

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Deployment to GitHub Pages

### Automatic Deployment

This project is configured for automatic deployment to GitHub Pages. When you push to the `main` branch, GitHub Actions will automatically build and deploy your site.

### Setup Instructions

1. **Create a GitHub repository** for this project

2. **Push your code** to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

3. **Enable GitHub Pages**:
   - Go to your repository on GitHub
   - Click "Settings" → "Pages"
   - Under "Build and deployment":
     - Source: Select "GitHub Actions"
   - The workflow will automatically deploy your site

4. **Access your site**:
   - Your site will be available at: `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/`
   - If using a custom domain, update the `base` in `vite.config.ts`

### Custom Domain Setup (Optional)

If you want to use a custom domain:

1. Add a `CNAME` file to the `public` folder with your domain name
2. Update `vite.config.ts`:
   ```ts
   export default defineConfig({
     base: '/', // Keep as '/' for custom domains
     // ...
   })
   ```
3. Configure your domain's DNS settings to point to GitHub Pages

## Project Structure

```
├── public/           # Static assets
├── src/
│   ├── App.tsx      # Main application component
│   ├── main.tsx     # Application entry point
│   └── index.css    # Global styles
├── .github/
│   └── workflows/
│       └── deploy.yml  # GitHub Actions workflow
└── dist/            # Production build (generated)
```

## License

© 2025 HubForge Global Impact Network. All rights reserved.
